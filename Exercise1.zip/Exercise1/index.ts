const prompts = require("prompt-sync")({sigint: true});
const questions = require("./questions.json");
const numberOfQuestions = questions.length

console.log("Questionaire Survey");
console.log("===================\n");

// Iterate through the questions and ask the questions and compare it to the answers
// Keep track of the correct answers and print out if you passed or failed
// TIP: Use the ask function below to prompt the user with a question
// e.g.: const answer = ask("What is the answer");

// ====================
// START HERE
// ==========

// DO NOT EDIT BELOW!

function ask(question: string): string | null {
    const userInput = prompts(question + " ");
    return userInput;
}


