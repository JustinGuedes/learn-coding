var prompts = require("prompt-sync")({ sigint: true });
var questions = require("./questions.json");
var numberOfQuestions = questions.length;
console.log("Questionaire Survey");
console.log("===================\n");
// Counter for total questions answered correctly
var totalAnswersCorrect = 0;
questions.forEach(function (question, index) {
    console.log("Question", index);
    console.log("==========");
    var ans = ask(question.question);
    if ((ans === null || ans === void 0 ? void 0 : ans.toLowerCase()) == question.answer.toLowerCase()) {
        totalAnswersCorrect += 1;
    }
    console.log();
});
console.log("Total Answers Correct:", totalAnswersCorrect);
if ((totalAnswersCorrect / numberOfQuestions * 1.0) > 0.5) {
    console.log("You passed!");
}
else {
    console.log("You failed");
}
function ask(question) {
    var userInput = prompts(question + " ");
    return userInput;
}
